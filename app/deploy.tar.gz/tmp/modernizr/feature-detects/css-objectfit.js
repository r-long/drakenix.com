
// dev.opera.com/articles/view/css3-object-fit-object-position/

Modernizr.addTest('object-fit',
	!!Modernizr.prefixed('objectFit')
);